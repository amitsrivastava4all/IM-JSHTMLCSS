var urlConfig={
    "itemURL":"http://127.0.0.1:51934/Item-CRUD/server/items.json",
    "productURL":""
}